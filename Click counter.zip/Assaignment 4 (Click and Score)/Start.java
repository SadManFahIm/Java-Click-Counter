public class Start{
	public static void main(String args[]){
		ClickScore c=new ClickScore();
		c.setVisible(true);
		c.run();	
	}
}