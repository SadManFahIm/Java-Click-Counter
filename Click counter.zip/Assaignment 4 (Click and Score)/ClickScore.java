import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ClickScore extends JFrame implements ActionListener,Runnable{
	private JButton button[]=new JButton[10];
	private JButton again,exit;
	private JLabel label,score;
	private JPanel panel;
	private int value,istrue;
	private int i=0,x=0;
	
	public ClickScore(){
		super("Click & Score");
		this.setSize(800,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel=new JPanel();
		panel.setBackground(Color.black);
		panel.setLayout(null);
		
		label=new JLabel("Click & Score");
		label.setForeground(Color.red);
		label.setFont(new Font("Algerian",Font.BOLD+Font.ITALIC,40));
		label.setBounds(200,50,400,40);
		panel.add(label);
		
		score=new JLabel("Total Score :"+value);
		score.setForeground(Color.green);
		score.setFont(new Font("Algerian",Font.BOLD+Font.ITALIC,20));
		score.setBounds(280,100,400,40);
		panel.add(score);
		
		button[0]=new JButton("Button 1");
		button[0].setBounds(200,150,100,40);
		button[0].setBackground(Color.red);
		button[0].addActionListener(this);
		panel.add(button[0]);
		
		button[1]=new JButton("Button 2");
		button[1].setBounds(400,150,100,40);
		button[1].setBackground(Color.red);
		button[1].addActionListener(this);
		panel.add(button[1]);
		
		button[2]=new JButton("Button 3");
		button[2].setBounds(200,200,100,40);
		button[2].setBackground(Color.red);
		button[2].addActionListener(this);
		panel.add(button[2]);
		
		button[3]=new JButton("Button 4");
		button[3].setBounds(400,200,100,40);
		button[3].setBackground(Color.red);
		button[3].addActionListener(this);
		panel.add(button[3]);
		
		button[4]=new JButton("Button 5");
		button[4].setBounds(200,250,100,40);
		button[4].setBackground(Color.red);
		button[4].addActionListener(this);
		panel.add(button[4]);
		
		button[5]=new JButton("Button 6");
		button[5].setBounds(400,250,100,40);
		button[5].setBackground(Color.red);
		button[5].addActionListener(this);
		panel.add(button[5]);
		
		button[6]=new JButton("Button 7");
		button[6].setBounds(200,300,100,40);
		button[6].setBackground(Color.red);
		button[6].addActionListener(this);
		panel.add(button[6]);
		
		button[7]=new JButton("Button 8");
		button[7].setBounds(400,300,100,40);
		button[7].setBackground(Color.red);
		button[7].addActionListener(this);
		panel.add(button[7]);
		
		button[8]=new JButton("Button 9");
		button[8].setBounds(200,350,100,40);
		button[8].setBackground(Color.red);
		button[8].addActionListener(this);
		panel.add(button[8]);
		
		button[9]=new JButton("Button 10");
		button[9].setBounds(400,350,100,40);
		button[9].setBackground(Color.red);
		button[9].addActionListener(this);
		panel.add(button[9]);
		
		exit=new JButton("Exit Game");
		exit.setBounds(250,430,200,50);
		exit.setForeground(Color.white);
		exit.setFont(new Font("Algerian",Font.BOLD+Font.ITALIC,20));
		exit.setBackground(Color.cyan);
		exit.addActionListener(this);
		panel.add(exit);
		
		this.add(panel);
		
	}
	
	
	public void actionPerformed(ActionEvent actionevent){
		String element=actionevent.getActionCommand();
		if(element.equals(exit.getText())){
			System.exit(0);
		}else if(istrue==2){
			JOptionPane.showMessageDialog(this,"'Start the game & Play Again'..");
		}else if(element.equals(button[0].getText()) && istrue==1){
			if(button[0].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[1].getText()) && istrue==1){
			if(button[1].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[2].getText()) && istrue==1){
			if(button[2].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[3].getText()) && istrue==1){
			if(button[3].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[4].getText()) && istrue==1){
			if(button[4].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[5].getText()) && istrue==1){
			if(button[5].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[6].getText()) && istrue==1){
			if(button[6].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[7].getText()) && istrue==1){
			if(button[7].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[8].getText()) && istrue==1){
			if(button[8].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[9].getText()) && istrue==1){
			if(button[9].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}else if(element.equals(button[10].getText()) && istrue==1){
			if(button[10].getBackground().equals(Color.green)){
				value+=5;
				score.setText("Total Score :"+value);
			}else{
				value-=5;
				score.setText("Total Score :"+value);
			}
		}
		
	}
	
	public void run(){
		Random r=new Random();
		for(int i=0;i<25;i++){
			x=r.nextInt(10);
			button[x].setBackground(Color.green);
			istrue=1;
		try{
		Thread.sleep(1500);
		}catch(Exception e){}
		button[x].setBackground(Color.red);
		}
		istrue=2;
	}
	
	
}